# Nosh Professional Restaurant Booking System

A complete Node.js + SQLite restaurant booking application.

## Included
- Customer booking page
- Real server-side database persistence
- Live availability checks by date/time
- Capacity protection to prevent overbooking
- Admin login
- Live admin dashboard (refreshes every 15 seconds)
- Confirm / cancel / delete bookings
- Menu management: add, edit, hide/show, delete, prices
- Configurable guest capacity per time slot
- Optional WhatsApp notifications through Twilio
- HTTPS-ready session cookie configuration

## Run locally

1. Install Node.js 20+.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Set environment variables from `.env.example`.

Windows PowerShell:
`$env:ADMIN_PASSWORD="YOUR_STRONG_PASSWORD"`
`$env:SESSION_SECRET="A_LONG_RANDOM_SECRET"`

macOS/Linux:
`export ADMIN_PASSWORD="YOUR_STRONG_PASSWORD"`
`export SESSION_SECRET="A_LONG_RANDOM_SECRET"`

5. Run `npm start`.
6. Customer website: `http://localhost:3000/`
7. Admin dashboard: `http://localhost:3000/admin.html`

## WhatsApp notifications

The application supports Twilio WhatsApp. Create/configure a Twilio WhatsApp sender and set:
- TWILIO_ACCOUNT_SID
- TWILIO_AUTH_TOKEN
- TWILIO_WHATSAPP_FROM
- RESTAURANT_WHATSAPP=whatsapp:+919129995797

The server sends a new-booking message to the restaurant number after a successful database insert. Without Twilio credentials, bookings still save correctly; only the WhatsApp notification is skipped.

For production, use a real Twilio WhatsApp sender/template configuration appropriate to the messaging rules for your account.

## Production deployment

Deploy the Node process on a host with persistent disk/database storage. Set all environment variables in the host's secret manager. Put the app behind HTTPS. Back up `nosh.db` regularly.

For multi-instance/cloud deployments, move the database to a managed database instead of local SQLite.

## Important

This package is a complete application codebase, but it is not automatically hosted by this chat. You still need to deploy it and configure the admin password and WhatsApp provider credentials.
