const express=require("express");
const Database=require("better-sqlite3");
const cookieSession=require("cookie-session");
const twilio=require("twilio");
const path=require("path");

const app=express();
const db=new Database(process.env.DB_PATH||"nosh.db");
db.pragma("journal_mode=WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS bookings(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL, phone TEXT NOT NULL, date TEXT NOT NULL, time TEXT NOT NULL,
 guests INTEGER NOT NULL, seating TEXT NOT NULL, request TEXT DEFAULT '',
 status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS menu_items(
 id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, name TEXT NOT NULL,
 description TEXT DEFAULT '', price INTEGER NOT NULL DEFAULT 0, available INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
`);
const defaults=[
["starters","Paneer Tikka","Char-grilled cottage cheese with peppers and house spices.",320],
["starters","Chicken Tikka","Tender marinated chicken with aromatic spices.",390],
["starters","Crispy Corn","Crunchy corn tossed with herbs and spices.",220],
["mains","Butter Chicken","Creamy tomato gravy with tender chicken.",420],
["mains","Paneer Butter Masala","Paneer in a rich tomato gravy.",360],
["mains","Dal Makhani","Slow-cooked black lentils finished with butter.",280],
["mains","Biryani","Fragrant basmati rice layered with aromatic spices.",360],
["breads","Butter Naan","Soft tandoor-baked naan finished with butter.",70],
["breads","Garlic Naan","Naan topped with garlic and herbs.",90],
["breads","Tandoori Roti","Crisp-edged whole-wheat roti.",45],
["desserts","Gulab Jamun","Warm syrup-soaked milk dumplings.",140],
["desserts","Brownie with Ice Cream","Warm chocolate brownie with ice cream.",220],
["drinks","Fresh Lime Soda","Refreshing lime with sweet or salted finish.",110],
["drinks","Cold Coffee","Chilled creamy coffee.",160]
];
if(db.prepare("SELECT COUNT(*) c FROM menu_items").get().c===0){
 const ins=db.prepare("INSERT INTO menu_items(category,name,description,price,created_at) VALUES(?,?,?,?,?)");
 const tx=db.transaction(()=>defaults.forEach(x=>ins.run(...x,new Date().toISOString()))); tx();
}
const getSetting=k=>db.prepare("SELECT value FROM settings WHERE key=?").get(k)?.value;
const setSetting=(k,v)=>db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(k,String(v));
if(!getSetting("slot_capacity")) setSetting("slot_capacity",40);

app.use(express.json());
app.use(cookieSession({
 name:"nosh_session",
 keys:[process.env.SESSION_SECRET||"CHANGE_ME_IN_PRODUCTION"],
 httpOnly:true,sameSite:"lax",
 secure:process.env.NODE_ENV==="production"
}));
app.use(express.static(path.join(__dirname,"public")));

function admin(req,res,next){ if(req.session?.admin===true)return next(); res.status(401).json({error:"Unauthorized"}); }

function validDateTime(date,time){
 const d=new Date(`${date}T${time}:00`);
 return !Number.isNaN(d.getTime()) && d.getTime()>=Date.now()-60000;
}
function notifyWhatsApp(booking){
 const sid=process.env.TWILIO_ACCOUNT_SID, token=process.env.TWILIO_AUTH_TOKEN;
 const from=process.env.TWILIO_WHATSAPP_FROM, to=process.env.RESTAURANT_WHATSAPP||"whatsapp:+919129995797";
 if(!sid||!token||!from) return Promise.resolve({sent:false,reason:"Twilio not configured"});
 try{
  const client=twilio(sid,token);
  const body=`🍽️ NOSH NEW TABLE BOOKING #${booking.id}\n\nName: ${booking.name}\nPhone: ${booking.phone}\nDate: ${booking.date}\nTime: ${booking.time}\nGuests: ${booking.guests}\nSeating: ${booking.seating}\nRequest: ${booking.request||"None"}\n\nOpen the admin dashboard to confirm or cancel.`;
  return client.messages.create({from,to,body}).then(()=>({sent:true})).catch(e=>({sent:false,reason:e.message}));
 }catch(e){return Promise.resolve({sent:false,reason:e.message});}
}

app.get("/api/menu",(req,res)=>{
 res.json(db.prepare("SELECT id,category,name,description,price FROM menu_items WHERE available=1 ORDER BY category,id").all());
});

app.get("/api/availability",(req,res)=>{
 const {date,time}=req.query;
 if(!date||!time||!validDateTime(date,time)) return res.status(400).json({error:"Choose a valid future date and time"});
 const capacity=Number(getSetting("slot_capacity")||40);
 const used=db.prepare("SELECT COALESCE(SUM(guests),0) guests FROM bookings WHERE date=? AND time=? AND status IN ('pending','confirmed')").get(date,time).guests;
 res.json({available:used<capacity,used,capacity,remaining:Math.max(0,capacity-used)});
});

app.post("/api/bookings",async(req,res)=>{
 const {name,phone,date,time,guests,seating,request=""}=req.body||{};
 const n=Number(guests);
 if(!name||!phone||!date||!time||!n||n<1||n>30||!seating||!validDateTime(date,time))
  return res.status(400).json({error:"Please enter valid booking details"});
 const capacity=Number(getSetting("slot_capacity")||40);
 const used=db.prepare("SELECT COALESCE(SUM(guests),0) guests FROM bookings WHERE date=? AND time=? AND status IN ('pending','confirmed')").get(date,time).guests;
 if(used+n>capacity)return res.status(409).json({error:`That time is full. Only ${Math.max(0,capacity-used)} guest spots remain.`});
 const now=new Date().toISOString();
 const info=db.prepare(`INSERT INTO bookings(name,phone,date,time,guests,seating,request,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)`)
 .run(name.trim(),phone.trim(),date,time,n,seating,request||"","pending",now,now);
 const booking={id:info.lastInsertRowid,name,phone,date,time,guests:n,seating,request};
 const whatsapp=await notifyWhatsApp(booking);
 res.json({ok:true,id:info.lastInsertRowid,status:"pending",whatsapp});
});

app.post("/api/admin/login",(req,res)=>{
 const password=process.env.ADMIN_PASSWORD;
 if(!password)return res.status(500).json({error:"ADMIN_PASSWORD is not configured"});
 if(req.body?.password!==password)return res.status(401).json({error:"Invalid password"});
 req.session.admin=true;res.json({ok:true});
});
app.post("/api/admin/logout",(req,res)=>{req.session=null;res.json({ok:true})});

app.get("/api/admin/bookings",admin,(req,res)=>{
 res.json(db.prepare("SELECT * FROM bookings ORDER BY date,time,id DESC").all());
});
app.patch("/api/admin/bookings/:id",admin,(req,res)=>{
 const status=req.body?.status;
 if(!["pending","confirmed","cancelled"].includes(status))return res.status(400).json({error:"Invalid status"});
 const result=db.prepare("UPDATE bookings SET status=?,updated_at=? WHERE id=?").run(status,new Date().toISOString(),req.params.id);
 if(!result.changes)return res.status(404).json({error:"Booking not found"});
 res.json({ok:true});
});
app.delete("/api/admin/bookings/:id",admin,(req,res)=>{
 const result=db.prepare("DELETE FROM bookings WHERE id=?").run(req.params.id);
 if(!result.changes)return res.status(404).json({error:"Booking not found"});
 res.json({ok:true});
});

app.get("/api/admin/menu",admin,(req,res)=>res.json(db.prepare("SELECT * FROM menu_items ORDER BY category,id").all()));
app.post("/api/admin/menu",admin,(req,res)=>{
 const {category,name,description="",price,available=true}=req.body||{};
 if(!category||!name||Number(price)<0)return res.status(400).json({error:"Invalid menu item"});
 const info=db.prepare("INSERT INTO menu_items(category,name,description,price,available,created_at) VALUES(?,?,?,?,?,?)").run(category,name,description||"",Number(price),available?1:0,new Date().toISOString());
 res.json({ok:true,id:info.lastInsertRowid});
});
app.patch("/api/admin/menu/:id",admin,(req,res)=>{
 const {category,name,description="",price,available}=req.body||{};
 const result=db.prepare("UPDATE menu_items SET category=?,name=?,description=?,price=?,available=? WHERE id=?")
 .run(category,name,description||"",Number(price),available?1:0,req.params.id);
 if(!result.changes)return res.status(404).json({error:"Menu item not found"});
 res.json({ok:true});
});
app.delete("/api/admin/menu/:id",admin,(req,res)=>{
 const result=db.prepare("DELETE FROM menu_items WHERE id=?").run(req.params.id);
 if(!result.changes)return res.status(404).json({error:"Menu item not found"});
 res.json({ok:true});
});
app.get("/api/admin/settings",admin,(req,res)=>res.json({slot_capacity:Number(getSetting("slot_capacity")||40)}));
app.patch("/api/admin/settings",admin,(req,res)=>{
 const cap=Number(req.body?.slot_capacity);
 if(!Number.isInteger(cap)||cap<1||cap>500)return res.status(400).json({error:"Capacity must be 1–500"});
 setSetting("slot_capacity",cap);res.json({ok:true});
});

app.get("/health",(req,res)=>res.json({ok:true}));
const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`Nosh professional booking server on :${port}`));